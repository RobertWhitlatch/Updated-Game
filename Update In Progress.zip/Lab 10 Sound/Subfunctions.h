// Subfunctions.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//************************Delayms***************************//
//Purpose: Delay for (n)ms, copied from ST7735.c.						//
//  Input: Number of ms to delay.														//
// Output: None																							//
//**********************************************************//

void  Delayms(uint32_t n);

//*********************PortF2_Init**************************//
//Purpose: Initialize Port F, Pin 2 for Synchronization			//
//         signaling.																				//
//  Input: None.																						//
// Output: None																							//
//**********************************************************//

void	PortF2_Init(void);

