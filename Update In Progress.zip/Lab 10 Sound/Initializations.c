// Initializations.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"

//************************I2C_Init**************************//
//Purpose: Initialize I2C0 on Port B, Pins 3-2.							//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void 	I2C_Init(void){
	
				SYSCTL_RCGCI2C_R |= 0x01;		 																				// Activate Clock for I2C0
				SYSCTL_RCGCGPIO_R 	|= 0x02; 																				// Activate Clock for Port B
				Delayms(1);																													// Delay for Operations to commence
				GPIO_PORTB_AFSEL_R  |= 0x0C;																			 	// Enable Alternate Functions for Port B, Pins 3-2
				GPIO_PORTB_ODR_R		|= 0x08;																				// Set Port B, Pin 3 as an Open Drain
				GPIO_PORTB_DEN_R 		|= 0x0C;																		 		// Enable Digital Input/Output for Port B, Pins 3-2
				GPIO_PORTB_PCTL_R		 = (GPIO_PORTB_PCTL_R&0xFFFF00FF)+0x00003300;		// Select I2C0 as Function
				GPIO_PORTB_AMSEL_R 	&= ~0x0C;																				// Disable Analog Functions for Port B, Pins 3-2
				I2C0_MCR_R 					 = 0x10;																				// Enable I2C0
				I2C0_MTPR_R 				 = 0x03;																				// Set Speed to 1Mbs

}

//**********************SysTick_Init************************//
//Purpose: Initialize Systick periodic interrupts.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void  SysTick_Init(void){
	
				NVIC_ST_CTRL_R 			= 0x00; 																				// Disable SysTick during Initialization
				NVIC_ST_RELOAD_R		= 0x001C58;																			// Load value for 1ms into SysTick Reload Register
				NVIC_ST_CURRENT_R		= 0x00;																					// Reset SysTick Current Register
				NVIC_SYS_PRI3_R 	 	= (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000;			// Set SysTick Interrupt Priority to 2 
				NVIC_ST_CTRL_R 			= 0x07; 																				// Enable SysTick concluding Initialization 

}
