// DiskOps.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

void	Disk_Init(void);

void  Data_Fetch(void);

uint16_t 	Format_Sample(void);
