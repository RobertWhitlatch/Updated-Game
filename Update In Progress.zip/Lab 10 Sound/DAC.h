// DAC.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//***********************Tx_Sample**************************//
//Purpose: Transmit 12-bit sound sample in 2 8-bit blasts.	//
//  Input: 12-bit sample.																		//
// Output: None																							//
//**********************************************************//

void	Tx_Sample(uint16_t Sample);



