// MainSound.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"
#include "Initializations.h"
#include "DAC.h"
#include "TExaS.h"
#include "edisk.h"
#include "DiskOps.h"
#include "Subfunctions.h"


uint8_t Start=0;
uint8_t Stop=0;

extern uint32_t BlockTracker;
extern uint8_t TimetoRead;
extern uint32_t SBReady;
extern uint16_t Index;

void EnableInterrupts(void);
void DisableInterrupts(void);

int	main(void){
	
			DisableInterrupts();
			TExaS_Init(SW_PIN_PE3210,DAC_PIN_PB3210,ScopeOn);
			PortF2_Init();
			while((GPIO_PORTF_DATA_R&0x04) == 0){};
			Delayms(170);
			Disk_Init();
			I2C_Init();
			Data_Fetch();
			SysTick_Init();

			EnableInterrupts();
			while(1){

				if(TimetoRead==1){Data_Fetch();TimetoRead=0;}
				if((GPIO_PORTF_DATA_R&0x04)==0){
					BlockTracker=0; SBReady=1;Index=0;
					Tx_Sample(0);
					while((GPIO_PORTF_DATA_R&0x04) == 0){};
				}
			}

}
