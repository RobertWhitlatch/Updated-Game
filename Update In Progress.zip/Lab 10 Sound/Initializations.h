// Initializations.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//************************I2C_Init**************************//
//Purpose: Initialize I2C0 on Port B, Pins 3-2.							//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void 	I2C_Init(void);

//**********************SysTick_Init************************//
//Purpose: Initialize Systick periodic interrupts.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void  SysTick_Init(void);
