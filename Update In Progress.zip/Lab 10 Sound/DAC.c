// DAC.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//***********************Tx_Sample**************************//
//Purpose: Transmit 12-bit sound sample in 2 8-bit blasts.	//
//  Input: 12-bit sample.																		//
// Output: None																							//
//**********************************************************//

void	Tx_Sample(uint16_t Sample){
				
				uint8_t Part1,Part2;
				Part1 = ((Sample&0xFF00)>>8);
				Part2 = (Sample&0xFF);
				I2C0_MSA_R = 0xC4;
				I2C0_MDR_R = (Part1&0xFF);
				I2C0_MCS_R = 0x03;
				while((I2C0_MCS_R&0x01) != 0){};
				if((I2C0_MCS_R&(0x08|0x4|0x2)) == 1){I2C0_MCS_R=0x4;}
				I2C0_MDR_R = (Part2&0xFF);
				I2C0_MCS_R = 0x05;
				while((I2C0_MCS_R&0x01) != 0){};
				if((I2C0_MCS_R&(0x08|0x4|0x2)) == 1){I2C0_MCS_R=0x4;}

}
