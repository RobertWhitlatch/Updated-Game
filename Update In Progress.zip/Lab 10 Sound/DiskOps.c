// DiskOps.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "eDisk.h"

#define StartBlock 568

int8_t  Result;
uint8_t SBReady=1;
uint8_t SBuffer1[512];
uint8_t *SB1pt=&SBuffer1[0];
uint8_t SBuffer2[512];
uint8_t *SB2pt=&SBuffer2[0];
uint32_t BlockTracker=StartBlock;
uint16_t Index=0;
uint8_t TimetoRead=0;

void	Disk_Init(void){

				Result = eDisk_Init(0);

			}

void  Data_Fetch(void){
	
				if(SBReady==1){
					SBReady++;
					Result=eDisk_ReadBlock(SB1pt,BlockTracker);
					
				}else{
					SBReady--;
					Result=eDisk_ReadBlock(SB2pt,BlockTracker);
				}
				BlockTracker++;
			}

uint16_t 	Format_Sample(void){
						
						uint16_t Sample=0;
						switch(SBReady){
							case 0x01:
								for(uint16_t i=1000;i!=0;i=i/10){
									Sample=Sample+((*(SB2pt+Index)-0x30)*i);
									Index++;
								}
								if(Index==512){
									Index=0;
									TimetoRead=1;
								}
								return(Sample);

							case 0x02:
								for(uint16_t i=1000;i!=0;i=i/10){
									Sample=Sample+((*(SB1pt+Index)-0x30)*i);
									Index++;
								}
								if(Index==512){
									Index=0;
									TimetoRead=1;
								}
								return(Sample);
						}
						return(0);	
}			
