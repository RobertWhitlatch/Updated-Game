// Subfunctions.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "DiskOps.h"
#include "Dac.h"

//**********************SysTick_Handle**********************//
//Purpose: Format and Transmit Audio Sample									//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void  SysTick_Handler(void){

				Tx_Sample(Format_Sample());

}

//************************Delayms***************************//
//Purpose: Delay for (n)ms, copied from ST7735.c.						//
//  Input: Number of ms to delay.														//
// Output: None																							//
//**********************************************************//

void  Delayms(uint32_t n){
				
				uint32_t volatile time;
				while(n){
					time = 0x01387F;  // 1msec, tuned at 80 MHz, Tested RMW
					while(time){
						time--;
					}
					n--;
				}
}

//*********************PortF2_Init**************************//
//Purpose: Initialize Port F, Pin 2 for Synchronization			//
//         signaling.																				//
//  Input: None.																						//
// Output: None																							//
//**********************************************************//

void	PortF2_Init(void){
				
				SYSCTL_RCGCGPIO_R |= 0x20;
				Delayms(1);
				GPIO_PORTF_AFSEL_R = 0x00;
				GPIO_PORTF_AMSEL_R = 0x00;
				GPIO_PORTF_DIR_R = 0x00;
				GPIO_PORTF_ODR_R = 0x04;
				GPIO_PORTF_DEN_R = 0x04;
	
}

