// Game Engine.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"
#include "ADC.h"

#define Unstruck	0
#define Struck		1

extern uint8_t GReady;
extern uint8_t RReady;
extern uint8_t YReady;
extern uint8_t BReady;
extern uint32_t HP;
extern uint32_t Score;
extern uint32_t Streak;
extern uint32_t Multiplier;
extern uint32_t UTime;

//*************************dHP******************************//
//Purpose: Updates Player HP and prevents overhealth and 		//
//				 negative health.																	//
//  Input: Amount Player HP is to change.										//
// Output: None																							//
//**********************************************************//

void 	dHP(int8_t n){
				
				HP = HP+n;
				if(HP<=0){HP=0;}
				if(HP>=40){HP=40;}
				return;

}

//*************************dScore***************************//
//Purpose: Increases Score based on Multiplier.							//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void 	dScore(void){
				
			Score = Score+50*Multiplier;
			return;
	
}

//***********************dStreak****************************//
//Purpose: Maintains Streak, as well as derive and display	//
//				 Multiplier.																			//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void 	dStreak(uint8_t n){
				Streak = (Streak+1)*n;
				Multiplier = (Streak/10);
				if(Multiplier>=4){Multiplier=4;}
				if(Multiplier<=1){Multiplier=1;}
				Digit_Display(Multiplier);
				return;
				
			}

//********************Strike_Checker************************//
//Purpose: Checks if guitar has been strummed, compares to 	//
//				 see if a note is present and is correct color.		//
//				 Utilizes and modifies Global Variables.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	Strike_Checker(void){
	
				uint32_t Sample; uint8_t static Current; uint8_t static Old;
				UTime++;
				Sample = ADC_In();
				Old = Current;
				if(Sample<=1900){
					Current=Struck;
				}else if(Sample>=2200){
					Current=Struck;
				}else{
					Current=Unstruck;
				}
				if(Current==Unstruck){
					return;
				}
				else if(Current==Old){
				return;
				}
				if(((GReady+RReady+YReady+BReady)&(GPIO_PORTE_DATA_R&0xF))>0){
					dHP(1); dScore(); dStreak(1);
				}else{
					dHP(-1); dStreak(0);
				}
				return;
					
}

