// Subfunctions.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//************************Delay1ms**************************//
//Purpose: Delay for n*1ms, copied from ST7735.c.						//
//  Input: Number of ms to delay.														//
// Output: None																							//
//**********************************************************//

void Delayms(uint32_t n);

//***********************PortC_Init*************************//
//Purpose: Initialize Port C																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortC_Init(void);

//***********************PortF_Init*************************//
//Purpose: Initialize Port F																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortF_Init(void);

//**********************SysTick_Init************************//
//Purpose: Initialize Systick periodic interrupts.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void SysTick_Init(void);

//***********************PortB_Init*************************//
//Purpose: Initialize Port B																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortB_Init(void);

//***********************PortB_Init*************************//
//Purpose: Initialize Port D																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortD_Init(void);


//*********************Digit_Display************************//
//Purpose: Display single digit on digit LCD								//
//  Input: 0-9 digit to be displayed												//
// Output: None																							//
//**********************************************************//

void 	Digit_Display(uint8_t Multiplier);
