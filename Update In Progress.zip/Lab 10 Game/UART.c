// UART1.c
// Runs on LM4F120/TM4C123
// Use UART1 to implement bidirectional data transfer to and from 
// another microcontroller in Lab 9.  This time, interrupts and FIFOs
// are used.
// Daniel Valvano
// November 17, 2014
// Modified by EE345L students Charlie Gough && Matt Hawk
// Modified by EE345M students Agustinus Darmawan && Mingjie Qiu

/* Lab solution, Do not post
 http://users.ece.utexas.edu/~valvano/
*/

// U1Rx (VCP receive) connected to PC4
// U1Tx (VCP transmit) connected to PC5
#include <stdint.h>
#include "FiFo.h"
#include "UART.h"
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"

#define PF2       (*((volatile uint32_t *)0x40025010))


uint32_t DataLost; 


// Initialize UART1
// Baud rate is 115200 bits/sec
// Make sure to turn ON UART1 Receiver Interrupt (Interrupt 6 in NVIC)
// Write UART1_Handler
void  UART_Init(void){
				
				SYSCTL_RCGCUART_R 	|= 0x00000002;  																						// Enable clock for UART1
				Delayms(1);																																			// Delay to ensure Clock Operation
				UART1_CTL_R  				&= ~0x0001;    																							// Disable UART1 Operations
				UART1_IBRD_R 				 = 43;     																									// IBRD = int(80,000,000/(16*115,200)) = int(43.40278)
				UART1_FBRD_R 				 = 26;     																									// FBRD = round(0.40278 * 64) = 26
				UART1_LCRH_R 				 = 0x0070;  																								// Set transmission style as 8-bit, no parity bit, one stop, FIFO's
				UART1_IFLS_R				 = (UART1_IFLS_R&0xFFFFFFC0);																// Clear Tx and Rx Interrupt fields
				UART1_IFLS_R				|= 0x10;																										// Set Interrupts to fire when Rx FIFO <= 1/2 full
				UART1_IM_R					|= 0x1F;																										// Arm UART1 Interrupts
				UART1_CTL_R 				|= 0x0301;     																							// Enable Tx, Rx, and UART1 Operations
				NVIC_PRI1_R					 = (NVIC_PRI1_R&0xFF1FFFFF)|0x00400000;											// Set UART1 Interrupts to Priority 2
				NVIC_EN0_R					|= 0x40;																										// Enable IRQ 6

}

// input ASCII character from UART
// spin if RxFifo is empty

char  UART_InChar(void){
				
				char sample;
				while((UART1_FR_R&0x10) == 1){}                        // Wait until RXFE is zero     
				sample = UART1_DR_R;
				return (sample);	

}

//------------UART1_OutChar------------
// Output 8-bit to serial port
// Input: letter is an 8-bit ASCII character to be transferred
// Output: none

void  UART_OutChar(char data){
				
				while ((UART1_FR_R&0x20) == 1){} 
				UART1_DR_R = data;

}

// hardware RX FIFO goes from 7 to 8 or more items
// UART receiver Interrupt is triggered; This is the ISR

void  UART1_Handler(void){

				char sample;
				PF2 ^= 0x04;
				PF2 ^= 0x04; 
				while((UART1_FR_R&0x10) == 0){ 
					sample = UART1_DR_R;
					FiFo_Put(sample); 
				}
				UART1_ICR_R = 0x10; 
				PF2 ^= 0x04;
				return;
	
}
