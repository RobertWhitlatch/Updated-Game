// ADC.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//********************PortE4_ADC_Init***********************//
//Purpose: Initialize Port E, Pin 4 for ADC use.						//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortE4_ADC_Init(void);

//*************************ADC_Init*************************//
//Purpose: Initialize ADC0 using SS3 on CH.9.								//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	ADC_Init(void);

//**************************ADC_In**************************//
//Purpose: Fetch result of ADC conversion.									//
//  Input: None																							//
// Output: 12-bit result of ADC conversion.									//
//**********************************************************//

uint16_t  ADC_In(void);
