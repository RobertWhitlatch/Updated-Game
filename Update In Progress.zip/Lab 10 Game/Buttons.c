// Buttons.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"

//********************PortE3210_Init************************//
//Purpose: Initialize Port E, Pins 3-0 as GPIO's.						//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortE3210_Init(void){

				SYSCTL_RCGCGPIO_R 	|= 0x10; 																										// Activate Clock for Port E
				Delayms(1);																																			// Delay to ensure Clock Operation
				GPIO_PORTE_AMSEL_R 	 = (GPIO_PORTE_AMSEL_R&0xFFFFFFF0)+0x00000000;							// Disable Analog Functions for Port E, Pins 3-0
				GPIO_PORTE_DIR_R 		 = (GPIO_PORTE_DIR_R&0xFFFFFFF0)+0x00000000;								// Set Port E, Pins 3-0 as Inputs 
				GPIO_PORTE_AFSEL_R 	 = (GPIO_PORTE_AFSEL_R&0xFFFFFFF0)+0x00000000; 							// Disable Alternate Functions for Port E, Pin 3-0
				GPIO_PORTE_PDR_R		 = (GPIO_PORTE_PDR_R&0xFFFFFFF0)+0x0000000F;								// Enable Pull Down Resistors for Port E, Pins 3-0
				GPIO_PORTE_DEN_R 		 = (GPIO_PORTE_DEN_R&0xFFFFFFFF0)+0x0000000F;								// Enable Digital Input/Output for Port E, Pin 3-0
	
}


