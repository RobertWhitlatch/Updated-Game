// Timers.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//*********************Timer4A_Init*************************//
//Purpose: Initializes Timer4A to intterrupt every 1ms.			//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	Timer4A_Init(void);

