// Subfunctions.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "ADC.h"
#include "ST7735.h"

extern uint16_t Screen_Buffer[129][161];

//************************Delay1ms**************************//
//Purpose: Delay for (n)ms, copied from ST7735.c.						//
//  Input: Number of ms to delay.														//
// Output: None																							//
//**********************************************************//

void  Delayms(uint32_t n){
				
				uint32_t volatile time;
				while(n){
					time = 72724*2/91;  // 1msec, tuned at 80 MHz
					while(time){
						time--;
					}
					n--;
				}
}

//**********************SysTick_Init************************//
//Purpose: Initialize Systick periodic interrupts.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void  SysTick_Init(void){
	
				NVIC_ST_CTRL_R 			= 0x00; 																				// Disable SysTick during Initialization
				NVIC_ST_RELOAD_R		= 0x0028B0AA;																		// Load value for 30Hz into SysTick Reload Register
				NVIC_ST_CURRENT_R		= 0x00;																					// Reset SysTick Current Register
				NVIC_SYS_PRI3_R 	 	= (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000;			// Set SysTick Interrupt Priority to 2 
				NVIC_ST_CTRL_R 			= 0x07; 																				// Enable SysTick concluding Initialization 

}

//**********************SysTick_Init************************//
//Purpose: Initialize Systick periodic interrupts.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	SysTick_Handler(void){
				
				ST7735_DrawBitmap(0,160,*Screen_Buffer,129,161);

}
//***********************PortF_Init*************************//
//Purpose: Initialize Port F																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortF_Init(void){

				// Clock Initialization for Port F
	
				SYSCTL_RCGCGPIO_R 	|= 0x20;																				// Activate Clock for Port F
				Delayms(1);																													// Delay to ensure Clock Operation

				// Port F Initialization

				GPIO_PORTF_LOCK_R		 = 0x4C4F434B;																	// Unlock Port F, Pin 0
				GPIO_PORTF_CR_R			 = 0x1F;																				// Enable changes to Port F, Pin 0
				GPIO_PORTF_AMSEL_R 	 = 0x00;		 																		// Disable Analog Functions for Port F
				GPIO_PORTF_DIR_R 		|= 0x0E; 																				// Set Port F Pin 3-1 as Output
				GPIO_PORTF_AFSEL_R 	 = 0x00; 																				// Disable Alternate Functions for Port F
				GPIO_PORTF_PUR_R		 = 0x00;																				// Disable weak pull up resistors on Port F
				GPIO_PORTF_DEN_R 		|= 0x0E; 																				// Enable Digital Input/Output for Port F, Pin 3-1
			
}

//***********************PortC_Init*************************//
//Purpose: Initialize Port C																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortC_Init(void){

				// Clock Initialization for Port C
	
				SYSCTL_RCGCGPIO_R 	|= 0x04; 																				// Activate Clock for Port C
				Delayms(1);																													// Delay to ensure Clock Operation

				// Port C Initialization

				GPIO_PORTC_AMSEL_R 	&= ~0x30;																				// Disable Analog Functions for Port C
				GPIO_PORTC_AFSEL_R 	|= 0x30; 																				// Disable Alternate Functions for Port C
				GPIO_PORTC_DEN_R 		|= 0x30; 																				// Enable Digital Input/Output for Port C, Pin 5-4
				GPIO_PORTC_PCTL_R 	 = (GPIO_PORTC_PCTL_R&0xFF00FFFF)+0x00220000;		// Enable UART1 as special function on Port C, Pin 5-4
			
}

//***********************PortB_Init*************************//
//Purpose: Initialize Port B																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortB_Init(void){

				// Clock Initialization for Port B
	
				SYSCTL_RCGCGPIO_R 	|= 0x02; 																				// Activate Clock for Port B
				Delayms(1);																													// Delay to ensure Clock Operation

				// Port B Initialization

				GPIO_PORTB_AMSEL_R 	 = 0x00;																				// Disable Analog Functions for Port B
				GPIO_PORTB_DIR_R 		|= 0xFF; 																				// Set Port B, Pins 7-0 as Output
				GPIO_PORTB_AFSEL_R 	|= 0x00; 																				// Disable Alternate Functions for Port B, Pins 7-0
				GPIO_PORTB_DEN_R 		|= 0xFF; 																				// Enable Digital Input/Output for Port B, Pins 7-0

}

//***********************PortB_Init*************************//
//Purpose: Initialize Port D																//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortD_Init(void){

				// Clock Initialization for Port D
	
				SYSCTL_RCGCGPIO_R 	|= 0x08; 																				// Activate Clock for Port D
				Delayms(1);																													// Delay to ensure Clock Operation

				// Port D Initialization

				GPIO_PORTD_AMSEL_R 	 = 0x00;																				// Disable Analog Functions for Port D
				GPIO_PORTD_DIR_R 		|= 0x0F; 																				// Set Port D, Pins 3-0 as Output
				GPIO_PORTD_AFSEL_R 	|= 0x0F; 																				// Disable Alternate Functions for Port D, Pins 3-0
				GPIO_PORTD_DEN_R 		|= 0x0F; 																				// Enable Digital Input/Output for Port D, Pins 3-0

}


//*********************Digit_Display************************//
//Purpose: Display single digit on digit LCD								//
//  Input: 0-9 digit to be displayed												//
// Output: None																							//
//**********************************************************//

void 	Digit_Display(uint8_t Multiplier){
	
				uint8_t Display_Values[10]={0x77,0x24,0x5D,0x6D,0x2E,0x6B,0x7B,0x25,0x7F,0x6F};
				GPIO_PORTB_DATA_R = Display_Values[Multiplier];

}
