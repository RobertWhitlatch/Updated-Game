// Buttons.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//********************PortE3210_Init************************//
//Purpose: Initialize Port E, Pins 3-0 as GPIO's.						//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortE3210_Init(void);

