// Main.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"
#include "Buttons.h"
#include "Game Engine.h"
#include "Timers.h"

void DisableInterrupts(void); 								// Disable interrupts
void EnableInterrupts(void);  								// Enable interrupts
uint32_t StartCritical (void);   							// previous I bit, disable interrupts
void EndCritical(uint32_t sr);   							// restore I bit to previous value
void WaitForInterrupt(void);  								// low power mode

uint32_t HP=25;
uint32_t Score=0;
uint32_t Streak=0;
uint32_t Multiplier=1;
uint8_t GReady=0;
uint8_t RReady=0;
uint8_t YReady=0;
uint8_t BReady=0;

int	main(){
			DisableInterrupts(); 						// Disable interrupts
			PLL_Init();
			EnableInterrupts();  						// Enable interrupts
			while(1){}

}

