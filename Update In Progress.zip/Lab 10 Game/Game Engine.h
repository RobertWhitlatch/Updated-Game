// Game Engine.h
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"

//*************************dHP******************************//
//Purpose: Updates Player HP and prevents overhealth and 		//
//				 negative health.																	//
//  Input: Amount Player HP is to change.										//
// Output: None																							//
//**********************************************************//

void dHP(uint8_t n);

//*************************dScore***************************//
//Purpose: Increases Score based on Multiplier.							//
//  Input: None																							//
// Output: None																							//
//**********************************************************//


void dScore(void);



void dStreak(uint8_t);


//********************Strike_Checker************************//
//Purpose: Checks if guitar has been strummed, compares to 	//
//				 see if a note is present and is correct color.		//
//				 Utilizes and modifies Global Variables.					//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	Strike_Checker(void);

