// ADC.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"
#include "StartEnd.h"

void Delay1ms(uint32_t);

//********************PortE4_ADC_Init***********************//
//Purpose: Initialize Port E, Pin 4 for ADC use.						//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	PortE4_ADC_Init(void){
	
				SYSCTL_RCGCGPIO_R 	|= 0x10; 																										// Activate Clock for Port F,E,A
				Delay1ms(1);																																			// Delay to ensure Clock Operation
				GPIO_PORTE_AMSEL_R 	 = (GPIO_PORTE_AMSEL_R&0xFFFFFFEF)+0x00000010;							// Enable Analog Functions for Port E, Pin 4
				GPIO_PORTE_DIR_R 		 = (GPIO_PORTE_DIR_R&0xFFFFFFEF)+0x00000000;								// Set Port E, Pin 4 as Input 
				GPIO_PORTE_AFSEL_R 	 = (GPIO_PORTE_AFSEL_R&0xFFFFFFEF)+0x00000010; 							// Enable Alternate Functions for Port E, Pin 4
				GPIO_PORTE_DEN_R 		 = (GPIO_PORTE_DEN_R&0xFFFFFFEF)+0x00000000;								// Disable Digital Input/Output for Port E, Pin 4
	
}

//*************************ADC_Init*************************//
//Purpose: Initialize ADC0 using SS3 on CH.9.								//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	ADC_Init(void){ 

				PortE4_ADC_Init();																															// Initialize Port E, Pin 4
				SYSCTL_RCGCADC_R		|= 0x00000001;																							// Enable ADC0 Clock
				Delay1ms(1);																																			// Delay to ensure Clock Operation
				ADC0_PC_R 					 = 0x01;																										// Set ADC0 Sampling frequency at 125KHz
				ADC0_SSPRI_R				 = 0x0123;																									// Set ADC0, Sequencer 3 at highest priority
				ADC0_ACTSS_R				 = ADC0_ACTSS_R&0xFFFFFFFF7;																// Disable Sequencer 3
				ADC0_EMUX_R					 = ADC0_EMUX_R&0xFFFF0FFF;																	// Set Sequencer 3 as Software Triggered
				ADC0_SSMUX3_R				 = (ADC0_SSMUX3_R&0xFFFFFFF0)+9;														// Set ADC0 to Channel 9 (Port E, Pin 4)
				ADC0_SSCTL3_R				 = 0x6;																											// Disable TS0 and D0, Enable IE0 and END0
				ADC0_IM_R						 = ADC0_IM_R&0xFFFFFFF7;																		// Disable Sequencer 3 Interrupts
				ADC0_ACTSS_R				|= 0x8;																											// Enable Sequencer 3																									// Enable Sequencer 3

}

//**************************ADC_In**************************//
//Purpose: Fetch result of ADC conversion.									//
//  Input: None																							//
// Output: 12-bit result of ADC conversion.									//
//**********************************************************//

uint16_t  ADC_In(void){
	
						uint16_t sample;																														// Establish variable to hold Sample
						ADC0_PSSI_R = 0x8;																													// Begin Sample
						while((ADC0_RIS_R&0x8)==0){};																								// Wait till Sample is complete
						sample = ADC0_SSFIFO3_R&0xFFF;																							// Pull Sample
						ADC0_ISC_R = 0x8;																														// Acknowledge Sample reception
						return(sample);																															// Return Sample

}
