// Timers.c
// Team SWEET Omega
// Last Modified: 4/28/17

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "Subfunctions.h"
#include "GameEngine.h"

uint32_t StartCritical (void);   							// previous I bit, disable interrupts
void EndCritical(uint32_t sr);   							// restore I bit to previous value

//*********************Timer4A_Init*************************//
//Purpose: Initializes Timer4A to intterrupt every 1ms.			//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void	Timer4A_Init(){
		
				uint32_t I;
				I = StartCritical();
				SYSCTL_RCGCTIMER_R |= 0x10;
				Delayms(1);
				TIMER4_CTL_R 				= 0x0;
				TIMER4_CFG_R 				= 0x4;
				TIMER4_TAMR_R				= 0x2;
				TIMER4_TAILR_R			=	0x1387F;
				TIMER4_TAPR_R				= 0x1;
				TIMER4_ICR_R				= 0x1;
				TIMER4_IMR_R				=	0x1;
				NVIC_PRI17_R 				= (NVIC_PRI17_R&0xFF00FFFF)+0x00400000;
				NVIC_EN2_R				 |= 0x00000040;
				TIMER4_CTL_R 				= 0x1;
				EndCritical(I);
	
}

//*******************Timer4A_Handler************************//
//Purpose: Acknowledge Interrput and call Strike_Checker.		//
//  Input: None																							//
// Output: None																							//
//**********************************************************//

void 	Timer4A_Handler(void){

				TIMER4_ICR_R = 0x1;																	// Acknowledge Timer4A Interrupt
				Strike_Checker();
 
}
