#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"
#include "StartEnd.h"
#include "Buttons.h"
#include "ADC.h"
#include "Timers.h"
#include "Subfunctions.h"

/*
#define ST7735_BLACK   0x0000
#define ST7735_BLUE    0xF800
#define ST7735_RED     0x001F
#define ST7735_GREEN   0x07E0
#define ST7735_CYAN    0xFFE0
#define ST7735_MAGENTA 0xF81F
#define ST7735_YELLOW  0x07FF
#define ST7735_WHITE   0xFFFF
*/

#define Black 0
#define Red 1
#define Green 2
#define Yellow 3
#define Blue 4
#define Magenta 5
#define Cyan 6
#define White 7

uint8_t ColorArray[]= {Green, Red, Yellow, Blue, Black};

uint16_t BigColorArray[8]={ST7735_BLACK,ST7735_BLUE,ST7735_RED,ST7735_GREEN,ST7735_CYAN,ST7735_MAGENTA,ST7735_YELLOW,
													ST7735_WHITE};
uint32_t shuffle=0;
void Delay1ms(uint32_t);
uint16_t	DecompressColor(uint8_t n);
int32_t 	XYtoI (int32_t x, int32_t y);
uint32_t StartFunc = 0;
extern uint32_t 	Score; 													
extern uint8_t VB[];
extern int16_t  	*Gpt;
extern int16_t	  *Rpt;
extern int16_t  	*Ypt;
extern int16_t  	*Blpt;
extern int16_t 		max;
extern uint8_t   *VBpt; 
extern uint8_t 	Gi,Ri,Yi,Bli;
extern uint8_t 	Gj,Rj,Yj,Blj;
extern uint32_t 	UniversalTime;		
extern int16_t Y_G[];		
extern int16_t Y_R[];		
extern int16_t Y_Y[];		
extern int16_t Y_Bl[];	
extern int8_t End;
													
void StartScreen(void){
			ST7735_FillRect(0 , 0  , 128 , 55 , ST7735_RED);
			ST7735_DrawChar(40, 60 , 'G' , ST7735_GREEN, ST7735_BLACK, 3);
			ST7735_DrawChar(57, 60 , 'E' , ST7735_GREEN, ST7735_BLACK, 3);
			ST7735_DrawChar(74, 60 , 'T' , ST7735_GREEN, ST7735_BLACK, 3);
			ST7735_FillRect(0 , 90 , 128 , 84 , ST7735_RED);
			Delay1ms(5000);
			ST7735_FillScreen(ST7735_GREEN);
			Delay1ms(2000); 
			ST7735_FillScreen(ST7735_BLACK);
	
			ST7735_FillRect(0 , 0  , 128 , 55 , ST7735_BLUE);
			ST7735_DrawChar(25, 60 , 'R' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(42, 60 , 'E' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(59, 60 , 'A' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(76, 60 , 'D' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(93, 60 , 'Y' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_FillRect(0 , 90 , 128 , 84 , ST7735_BLUE);
			Delay1ms(5000);
			ST7735_FillScreen(ST7735_RED);
			Delay1ms(2000); 
			ST7735_FillScreen(ST7735_BLACK);
	
			ST7735_FillRect(0 , 0  , 128 , 55 , ST7735_YELLOW);
			ST7735_DrawChar(49, 60 , 'T' , ST7735_MAGENTA, ST7735_BLACK, 3);
			ST7735_DrawChar(66, 60 , 'O' , ST7735_MAGENTA, ST7735_BLACK, 3);
			ST7735_FillRect(0 , 90 , 128 , 84 , ST7735_YELLOW);
			Delay1ms(5000);
			ST7735_FillScreen(ST7735_RED);
			Delay1ms(2000); 
			ST7735_FillScreen(ST7735_BLACK);
		
			ST7735_FillRect(0 , 0  , 128 , 55 , ST7735_WHITE);
			ST7735_DrawChar(35, 60 , 'R' , ST7735_WHITE, ST7735_BLACK, 3);
			ST7735_DrawChar(52, 60 , '0' , ST7735_WHITE, ST7735_BLACK, 3);
			ST7735_DrawChar(69, 60 , 'C' , ST7735_WHITE, ST7735_BLACK, 3);
			ST7735_DrawChar(86, 60 , 'K' , ST7735_WHITE, ST7735_BLACK, 3);
			ST7735_FillRect(0 , 90 , 128 , 84 , ST7735_WHITE);
			Delay1ms(5000);
			ST7735_FillScreen(ST7735_RED);
			Delay1ms(2000); 
			ST7735_FillScreen(ST7735_BLACK);

			ST7735_DrawChar(25, 85 , 'S' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(42, 85 , 'T' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(59, 85 , 'A' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(76, 85 , 'R' , ST7735_RED, ST7735_BLACK, 3);
			ST7735_DrawChar(93, 85 , 'T' , ST7735_RED, ST7735_BLACK, 3);
				
			for(uint8_t bull;bull<5;bull++){ //CONDITION THIS WITH PE5
			ST7735_FillRect(0,0,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(26,0,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(52,0,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(78,0,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(104,0,26,43,BigColorArray[shuffle]);	
			shuffle++; shuffle = shuffle%8;				
			ST7735_FillRect(0,117,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(26,117,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(52,117,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(78,117,26,43,BigColorArray[shuffle]);
			shuffle++; shuffle = shuffle%8;
			ST7735_FillRect(104,117,26,43,BigColorArray[shuffle]);	
			shuffle++; shuffle = shuffle%8;
			Delay1ms(2000);			
}			ST7735_FillScreen(ST7735_BLACK); return;}

extern int32_t HP;
void EndWinScreen (void){
			ST7735_FillScreen(ST7735_BLACK);
			ST7735_OutString("Score:");ST7735_OutUDec(Score);
		  ST7735_DrawChar(0, 10  , 'i' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(6, 10  , 'f' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(11,10  , '(' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(16,10  , 'Y' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(21,10  , 'O' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(26,10  , 'U' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(31,10  , '!' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(36,10  , '=' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(41,10  , 'P' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(46,10  , 'R' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(51,10  , 'O' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(56,10  , 'F' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(61,10  , ')' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(66,10  , '{' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(5,20 , 'Y' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(11,20 , 'O' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(16,20 , 'U' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(21,20 , '=' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(26,20 , 'R' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(31,20 , 'O' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(36,20 , 'C' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(41,20 , 'K' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(46,20 , ';' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(0,30  , '}' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(6,30  , 'e' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(11,30 , 'l' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(16,30 , 's' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(21,30 , 'e' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(26,30 ,'{'  , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(25,40 , 'M',ST7735_WHITE, ST7735_BLACK,  1);
			ST7735_DrawChar(31,40 , 'E' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(36,40 , '=' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(41,40 , 'A' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(46,40 , '+' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(51,40 , ';' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(5, 50 , '}' , ST7735_WHITE, ST7735_BLACK,  1);
			while((GPIO_PORTE_DATA_R&0x20) !=0x20 ){}
			max = -5;
			UniversalTime=30;	
			Gi=0;Ri=0;Yi=0;Bli=0;
			Gj=0;Rj=0;Yj=0;Blj=0;
			End=0;
			ST7735_FillScreen(ST7735_BLACK);
			for(uint32_t p=0;p<=16100;p++){
				VB[p]=0;
			}
			HP=90;
			StartScreen();
			DesignVB();DesignHP();	
			GPIO_PORTF_DATA_R = 0x04;
			return;
		}

void EndLoseScreen (void){
			ST7735_FillScreen(ST7735_BLACK);
			ST7735_OutString("Score:");ST7735_OutUDec(Score);
		  ST7735_DrawChar(0, 10  , 'i' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(6, 10  , 'f' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(11,10  , '(' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(16,10  , 'Y' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(21,10  , 'O' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(26,10  , 'U' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(31,10  , '!' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(36,10  , '=' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(41,10  , 'P' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(46,10  , 'R' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(51,10  , 'O' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(56,10  , 'F' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(61,10  , ')' , ST7735_WHITE, ST7735_BLACK,1);
			ST7735_DrawChar(66,10  , '{' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(5,20 , 'Y' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(11,20 , 'O' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(16,20 , 'U' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(21,20 , '=' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(26,20 , 'S' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(31,20 , 'U' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(36,20 , 'C' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(41,20 , 'K' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(46,20 , ';' , ST7735_WHITE, ST7735_BLACK, 1);	
			ST7735_DrawChar(0,30  , '}' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(6,30  , 'e' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(11,30 , 'l' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(16,30 , 's' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(21,30 , 'e' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(26,30 ,'{'  , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(25,40 , 'M',ST7735_WHITE, ST7735_BLACK,  1);
			ST7735_DrawChar(31,40 , 'E' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(36,40 , '=' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(41,40 , 'A' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(46,40 , '+' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(51,40 , ';' , ST7735_WHITE, ST7735_BLACK, 1);
			ST7735_DrawChar(5, 50 , '}' , ST7735_WHITE, ST7735_BLACK,  1);
			while((GPIO_PORTE_DATA_R&0x20) !=0x20 ){}
			max = -5;
			UniversalTime=30;	
			Gi=0;Ri=0;Yi=0;Bli=0;
			Gj=0;Rj=0;Yj=0;Blj=0;
			End=0;
			ST7735_FillScreen(ST7735_BLACK);
			for(uint32_t p=0;p<=16100;p++){
				VB[p]=0;
			}
			HP=90;
			StartScreen();
			DesignVB();DesignHP();
			GPIO_PORTF_DATA_R = 0x04;
			return;
		}
void DesignHP (void){
			ST7735_FillRect(99,120,29,40,ST7735_RED);
			ST7735_FillRect(99,80,29,40,ST7735_YELLOW);
			ST7735_FillRect(99,70,29,10,ST7735_GREEN);
}

void DesignVB(void){
			for(uint8_t LineOffset=1;LineOffset<4;LineOffset++){
				for(uint32_t Line=0;Line<161;Line++){
					VB[XYtoI(((LineOffset*25)-2),Line)] = Cyan;
				}
			}
			for(uint8_t Nib=1;Nib<4;Nib++){ 
				for(uint8_t NibH=0;NibH<12;NibH++){
					VB[XYtoI((Nib*25)-2,7+NibH)] = Magenta;//ColorArray[Nib];			
				}
			}	
		}

