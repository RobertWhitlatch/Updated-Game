#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"

void StartScreen(void);

void DesignVB(void);

void DesignHP (void);

void EndWinScreen (void);

void EndLoseScreen (void);

void EdgeInterrupt(void);

