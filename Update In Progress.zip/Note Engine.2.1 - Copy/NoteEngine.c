#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"
#include "StartEnd.h"
#include "Buttons.h"
#include "ADC.h"
#include "Timers.h"
#include "Subfunctions.h"
#include "GameEngine.h"

#define Black 0
#define Red 1
#define Green 2
#define Yellow 3
#define Blue 4
#define Magenta 5
#define Cyan 6
#define White 7

void EnableInterrupts(void);
void DisableInterrupts(void);

uint32_t  	Time_Green[] = {35,40,44,48,53, 
									    57,62,66,107,111,
									    116,120,125,130,134,
									    139,998,1034,//4,8
											1070,1106,1520,1556,1592,//2,17,24,28,32
											1628,1669,1680,1706,1717,//36,39,41,44,46
											1742,1753,1778,1789,1958,//49,51,54,56
											1967,1994,2003,2025,2029,
											2034,2047,2070,2279,2290,//75,77
										  2314,2325,2350,2361,2386,//80,82,85,87,90
											2397,2421,2456,2492,2527,//92
											2597,2606,2668,2712
};

uint32_t  	Time_Red[] = {71,75,80,85,89,94,
									 98,102,143,148,152,
									 156,161,166,170,175,
									 183,202,206,210,219,
									 237,242,246,255,273,
									 278,282,291,309,313,
									 318,327,345,350,354,
									 363,381,386,390,399,
									 417,422,426,435,453,
									 458,462,471,489,494,
									 498,507,525,530,535,
									 544,562,566,571,579,
									 598,602,606,616,634,
									 638,643,652,669,674,
									 678,687,705,710,714,
									 723,742,746,750,759,
									 777,782,786,795,813,
								   818,822,831,849,854,
									 858,867,885,890,894,
									 903,921,926,930,939,
									 957,962,966,980,1007,//2,5
									 1016,1052,1088,1119,1137,//6,10,14	
									 1142,1146,1191,1209,1214,
									 1218,1228,1246,1250,1255,
									 1264,1281,1286,1290,1335,
									 1353,1358,1362,1408,1425,
									 1430,1434,1480,1498,1502,
									 1507,1516,1543,1551,1578,//23,25,27,29
									 1587,1615,1624,1662,1674,//31,33,35,38,40
									 1699,1710,1735,1746,1771,//43,45,48,50,53
									 1783,1951,1974,1985,1998,//55
									 2020,2039,2056,2061,2065,
									 2074,2094,2101,2105,2118,
									 2129,2136,2140,2154,2165,//62,64
									 2172,2176,2190,2201,2208,//65,66,70,71
									 2216,2226,2234,2252,2257,//72
									 2261,2272,2283,2308,2319,//75,76,79,81
									 2343,2354,2379,2390,2558,//84,86,88,91
									 2646,2660,2677,2686,2719,
									 2721,2813,2836,2856,2861,
									 2867,2878,2902,2909,2915,100000
};

uint32_t  	Time_Yellow[] = {197,233,269,304,341,
									 377,413,449,485,521,
									 557,593,629,665,701,
									 737,773,809,845,881,
									 917,953,971,980,991,//1,2,3
									 998,1007,1016,1027,1034,//4,5,6,7,8
									 1043,1052,1063,1070,1079,//9,10,11,12,13
									 1088,1099,1106,1132,1151,//14,15,16,17,18	
									 1205,1241,1277,1295,1349,//19,
									 1367,1421,1439,1493,1511,//20,21,22
									 1520,1547,1556,1583,1592,//24,26,28,30,32
									 1619,1628,1656,1669,1680,//34,36,37,39,41
									 1692,1706,1717,1728,1742,//42,44,46,47,49
									 1753,1765,1778,1789,1801,//51,52,54,56,57,
									 1837,1873,1880,1909,1915,//58,59,60,
									 2087,2109,2114,2145,2149,//61
									 2158,2172,2176,2181,2185,//63,65,66,67,68
									 2194,2208,2216,2217,2221,//71,72,73
									 2248,2266,2279,2290,2301,//74,75,77,78
									 2314,2325,2336,2350,2361,//80,82,83,85,87
									 2372,2386,2397,2443,2553,//88,90,92
									 2587,2633,2638,2642,2739,
									 2748,2748,2765,2769,2774,
									 2778,2800,2805,2818,2851,
									 2896,2922,100000//last
									 };

uint32_t	 	Time_Bluel[]= {193,215,224,
									 228,251,260,264,287,
									 296,300,322,332,336,
								   359,368,372,395,404,
									 408,431,440,444,467,
									 476,480,503,512,516,
									 539,548,553,577,584,
									 589,611,620,624,647,
									 656,660,683,692,696,
									 719,728,732,755,764,
									 768,791,802,804,827,
									 836,840,863,872,876,
									 899,908,912,935,944,
									 948,971,991,1027,1043,//1,3,7,9
									 1063,1079,1099,1115,1124,//11,13,15
									 1128,1151,1187,1196,1200,//18	
									 1223,1232,1237,1255,1268,
									 1272,1295,1331,1340,1344,//19
									 1367,1403,1412,1416,1439,//20,21
									 1475,1484,1489,1511,1516,//22,23
									 1525,1543,1547,1551,1578,//25,26,27,29
									 1583,1587,1615,1619,1624,//30,31,33,34,35
									 1656,1662,1674,1692,1699,//37,38,40,42,43
									 1710,1728,1735,1746,1765,//45,48,50,52
									 1771,1783,1801,1837,1880,//53,55,57,58,59
									 1915,1933,1945,1963,1981,//60
									 2012,2087,2123,2129,2158,//61,62,63
									 2165,2181,2185,2194,2201,//64,67,68,69,60
									 2217,2221,2230,2239,2243,//72,73
									 2266,2272,2283,2301,2308,//74,75,76,78,79
									 2319,2336,2343,2354,2372,//81,83,84,86,88
									 2379,2390,2408,2478,2513,//89,91
									 2622,2690,2696,2700,2707,
									 2730,2791,2831,2840,2846,
									 2872,2884,2889,2922//last
};

int16_t  	Ypos_Green[] = {0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF
};
int16_t  	Ypos_Red[] = {0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF
};
int16_t  	Ypos_Yellow[] = {0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
};
int16_t  	Ypos_Blue[]= {
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF,0xFF,0xFF,
									 0xFF,0xFF,0xFF
};
int16_t  	*Gpt = &Ypos_Green[0];
int16_t	  *Rpt = &Ypos_Red[0];
int16_t  	*Ypt = &Ypos_Yellow[0];
int16_t  	*Blpt = &Ypos_Blue[0];
int16_t 	max = -5;
uint8_t   VB[(100*161)]; 
uint8_t   *VBpt = &VB[0];  
uint8_t 	Gi,Ri,Yi,Bli = 0; 
uint8_t 	Gj,Rj,Yj,Blj = 0;	
uint8_t 	Gk,Rk,Yk,Blk = 0; 
uint32_t 	UniversalTime=30;
extern int8_t 		End;
uint16_t	DecompressColor(uint8_t n){

						uint16_t Color;
						switch(n){
							case 0: Color = 0x0000;break;
							case 1: Color = 0x001F;break;
							case 2: Color = 0x07E0;break;
							case 3: Color = 0x07FF;break;
							case 4: Color = 0xF800;break;
							case 5: Color = 0xF81F;break;
							case 6: Color = 0xFFE0;break;
							case 7: Color = 0xFFFF;break;
						}
							//Color = (((n&0x4)<<13)+0x0F)|((n&0x2)<<9)|((n&0x1)<<4);          // 3-bit color
						return(Color);
}

int32_t 	XYtoI (int32_t x, int32_t y) {
					
						int32_t z = 0;
						z=(y*99)+x;
						return(z);
					}


#define Width 20
#define MaxNotes 6
					
void 	NoteOut(uint32_t b,int16_t *pt,int8_t c){
				for(uint8_t o=0;o<Width;o++){
					VB[XYtoI(b+o,*pt)+495] = 0x00;		//640 for full 
				}
				for(uint8_t o=0;o<Width;o++){
					VB[XYtoI(b+o,*pt)+594] = 0x00;		//640 for full 
				}
				for(uint8_t o=0;o<Width;o++){
					VB[XYtoI(b+o,*pt)+693] = 0x00;		//640 for full 
				}
				for(uint8_t o=0;o<Width;o++){
					VB[XYtoI(b+o,*pt)+792] = 0x00;		//640 for full 
				}
				for(uint8_t o=0;o<Width;o++){
					VB[XYtoI(b+o,*pt)+891] = 0x00;		//640 for full 
				}				
				for(uint8_t o=0;o<Width;o++){
					VB[XYtoI(b+o,*pt)+990] = 0x00;		//640 for full 
				}				
				for(uint8_t l = 0 ;l<6;l++){
					for(uint8_t m = 0;m<Width;m++){
						if(XYtoI(b+m,*pt+l)>0){ 
							if(XYtoI(b+m,*pt+l)<16100){
								VB[XYtoI(b+m,*pt+l)] = c;
							}
						}
					}
				}
				return;
			}

void 	NoteUpdateG(void){
				if (UniversalTime == 3000){End = 1; return;}
				if (UniversalTime == Time_Green[Gi]){
					Ypos_Green[Gj] = 165;
					Gi++;Gj++; 
				}
				if(*Gpt == 0xFF){return;}
				else{ 
					for (Gk=0;Gk<MaxNotes;Gk++){
						if (*(Gpt+Gk) != 0xFF){
							if(*(Gpt+Gk) == max){break;}
							*(Gpt+Gk) = *(Gpt+Gk)-5;
							NoteOut(0,Gpt+Gk,Green);
						}
					}
				}
				if(*Gpt == max){*Gpt=0xFF; Gpt++;}	
				return;
			}

void 	NoteUpdateR(void){
				if(UniversalTime == Time_Red[Ri]){
					Ypos_Red[Rj] = 165;
					Ri++;Rj++; 
				}
				if (*Rpt == 0xFF){return;}
				else{ 
					for(Rk=0;Rk<MaxNotes;Rk++){
						if(*(Rpt+Rk) != 0xFF){
							if(*(Rpt+Rk) == max){break;}
							*(Rpt+Rk) = *(Rpt+Rk)-5;
							NoteOut(25,Rpt+Rk,Red);
							}
						}
					}
				if(*Rpt == max){*Rpt=0xFF;Rpt++;}
				return;
			}

void 	NoteUpdateY(void){

				if (UniversalTime == Time_Yellow[Yi]){
					Ypos_Yellow[Yj] = 165;
					Yi++;Yj++; 
				}
				if(*Ypt == 0xFF){return;}
				else{ 
					for(Yk=0;Yk<MaxNotes;Yk++){
						if(*(Ypt+Yk) != 0xFF){
							if(*(Ypt+Yk) == max){break;}
						*(Ypt+Yk) = *(Ypt+Yk)-5;
						NoteOut(50,Ypt+Yk,Yellow);
						}
					}
				}
				if(*Ypt == max){*Ypt=0xFF;Ypt++;}
				return;
			}

void 	NoteUpdateBl(void){

				if(UniversalTime == Time_Bluel[Bli]){
					Ypos_Blue[Blj] = 165;
					Bli++;Blj++; 
				}
				if(*Blpt == 0xFF){return;}
				else{ 
					for(Blk=0;Blk<MaxNotes;Blk++){
						if(*(Blpt+Blk) != 0xFF){
							*(Blpt+Blk) = *(Blpt+Blk)-5;
							NoteOut(75,Blpt+Blk,Blue); 
						}
					}
				}
				if(*Blpt == max){*Blpt=0xFF;Blpt++;}
				return;
			}


void 	NoteUpdateAll(void){

				NoteUpdateG();
				NoteUpdateR();
				NoteUpdateY();
				NoteUpdateBl();

}
int32_t HP=90;
uint32_t OldHP;
uint16_t ColorHP;
int16_t HPDelta;
void	ControlHP (int32_t HP){ 
				if(HP>=160){return;
				}
				if(OldHP==HP){return;
				}
				if(OldHP>HP){
					//HPDelta=HP-OldHP;
					for(uint8_t erase=0;erase<9;erase++){
					ST7735_DrawFastHLine(99,144-HP+erase,29,ST7735_BLACK);
				}}
				if(HP>OldHP){
					//HPDelta=HP-OldHP;
					for(uint8_t draw = 0; draw <2 ; draw++){
					if(HP>=80){ColorHP = ST7735_GREEN;}
					if(HP<80){ColorHP = ST7735_YELLOW;}
					if(HP<=40){ColorHP = ST7735_RED;}
					ST7735_DrawFastHLine(99,160-HP+draw,29,ColorHP);
				}}
				HPDelta=0;
				OldHP = HP;
			}

int32_t temp[1]={165};
int32_t *temppt = &temp[0];
int8_t	DrawFlag=0;

void Delay1ms(uint32_t);

void  SysTick_Init(void){
	
				NVIC_ST_CTRL_R 			= 0x00; 																				// Disable SysTick during Initialization
				NVIC_ST_RELOAD_R		= 0x7A1200;																		 	    // Load value for  into SysTick Reload Register
				NVIC_ST_CURRENT_R		= 0x00;																					// Reset SysTick Current Register
				NVIC_SYS_PRI3_R 	 	= (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000;			// Set SysTick Interrupt Priority to 2 
				NVIC_ST_CTRL_R 			= 0x07; 																				// Enable SysTick concluding Initialization 

}

void SysTick_Handler(void){
			UniversalTime++;
			NoteUpdateAll();
			if(*Gpt != max){if(*Gpt != 0xFF){DrawFlag=1;}}
			if(*Rpt != max){if(*Rpt != 0xFF){DrawFlag=1;}}
			if(*Ypt != max){if(*Ypt != 0xFF){DrawFlag=1;}}
			if(*Blpt!= max){if(*Blpt != 0xFF){DrawFlag=1;}}
}
extern uint32_t Multiplier;
extern uint8_t Streak;
uint8_t Test[]={0,10,20,30,40,50,60};
uint8_t hope;
int	main(void){
			PLL_Init(); 
			ST7735_InitR(INITR_REDTAB);
			PortE53210_Init();	
			ADC_Init();
			PortF2_Init();
			PortB_Init();
			Digit_Display(Multiplier);
			StartScreen();
			Timer4A_Init();
			SysTick_Init();
			PortE4_ADC_Init();
			DesignVB();
			DesignHP();
			OldHP = HP;
			EnableInterrupts();
			GPIO_PORTF_DATA_R = 0x04;
			while(1){	
			if(DrawFlag==1){
			DisableInterrupts();
			ST7735_DrawBitmap(0,160,VB,99,160); DrawFlag=0 ;EnableInterrupts();}
			if (UniversalTime == 3000){End = 1;}
			ControlHP(HP);
			if(End== -1){GPIO_PORTF_DATA_R = 0x00;
			*Gpt = Ypos_Green[0];*Ypt= Ypos_Yellow[0];*Rpt=Ypos_Red[0];*Blpt=Ypos_Blue[0]; 
			EndLoseScreen();
			}
			if(End==1){GPIO_PORTF_DATA_R = 0x00;
			*Gpt = Ypos_Green[0];*Ypt= Ypos_Yellow[0];*Rpt=Ypos_Red[0];*Blpt=Ypos_Blue[0]; 
			EndWinScreen();
			}
		}
	}
