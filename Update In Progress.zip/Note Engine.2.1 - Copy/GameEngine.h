#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"
#include "StartEnd.h"
#include "ADC.h"

void	Strike_Checker(void);

void UpdateScore (void);
	
//uint8_t UpdateStreak (uint8_t Streak , uint8_t n);

uint32_t UpdateHP (int8_t hitpoints);

void 	Digit_Display(uint8_t Multiplier);

uint32_t UpdateHP (int8_t hitpoints);
