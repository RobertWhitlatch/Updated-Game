#include <stdint.h>
#include "ST7735.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"
#include "StartEnd.h"
#include "ADC.h"

extern int16_t  	*Gpt;
extern int16_t	  *Rpt;
extern int16_t  	*Ypt;
extern int16_t  	*Blpt;
extern uint8_t VB[];
extern int32_t HP;

int8_t 		hitpoints=0;
int8_t 		End = 0;
uint8_t 	Streak=0;
uint32_t 	Multiplier=1;
uint32_t 	Score=0; 


int32_t 	XYtoI (int32_t x, int32_t y);
void	ControlHP (int32_t HP, int8_t hitpoints);
//*********************Digit_Display************************//
//Purpose: Display single digit on digit LCD								//
//  Input: 0-9 digit to be displayed												//
// Output: None																							//
//**********************************************************//

void 	Digit_Display(uint8_t  multiplier){
	
				uint8_t Display_Values[10]={0x77,0x24,0x5D,0x6D,0x2E,0x6B,0x7B,0x25,0x7F,0x6F};
				GPIO_PORTB_DATA_R = Display_Values[multiplier];

}

 uint32_t UpdateHP (int8_t hitpoints){ 			
				HP = HP+hitpoints;
				if(HP<=0){HP=0;End=-1;}
				if(HP>=160){HP=160;}
				return(HP);
			}
 
 //uint8_t UpdateStreak (uint8_t Streak , uint32_t n){
//					Streak = (Streak+1)*n;
	//				Multiplier = ((Streak/10)+1);
		//			if(Multiplier>=4){Multiplier=4;}
			//		if(Multiplier<=1){Multiplier=1;}
//					Digit_Display(Multiplier);
	//				return(Streak);
		//			}
 
void UpdateScore (void){
				Score = Score+50*Multiplier;
}

 void	Strike_Checker(void){
				
				uint32_t Sample , PortESample , PointerSample=0, Struck = 1, Unstruck = 0;
				uint8_t static Current;
				uint8_t static Old;
				Sample = ADC_In();
				PortESample=GPIO_PORTE_DATA_R&0x0000000F;
	 
				Old = Current;
				if(Sample<=1900){Current=Struck;}
				else if(Sample>=2200){Current=Struck;}
				else{Current=Unstruck;}
				if(Current==Unstruck){
				if (*Gpt < 0){if(*Gpt > -5){ UpdateHP(-2);}}
				if (*Rpt < 0){if(*Rpt > -5){ UpdateHP(-2);}}
				if (*Ypt < 0){if(*Ypt > -5){ UpdateHP(-2);}}
				if (*Blpt< 0){if(*Blpt> -5){ UpdateHP(-2);}}
				return;}
				else if(Current==Old){return;}
				
				if (PortESample==0){ 
					//UpdateStreak(Streak , Unstruck);
					Streak=0;
					Multiplier=1;
					UpdateHP(-8);
					return;
					}else{ 
				if (*Gpt < 25){if(*Gpt > 0){ PointerSample = PointerSample + 1;}}
				if (*Rpt < 25){if(*Rpt > 0){ PointerSample = PointerSample + 4;}}
				if (*Ypt < 25){if(*Ypt > 0){ PointerSample = PointerSample + 2;}}
				if (*Blpt< 25){if(*Blpt> 0){ PointerSample = PointerSample + 8;}}
				if (PointerSample == PortESample){
					//UpdateStreak(Streak , Struck);
					Streak++;
					Multiplier = ((Streak/10)+1);
					if(Multiplier==5){Multiplier = 4;}
					Digit_Display(Multiplier);
					UpdateHP(2);
					UpdateScore();
				}else{
					//UpdateStreak(Streak , Unstruck);
					Streak=0;
					Multiplier=1;
					UpdateHP(-8);
					return;
				}
			}
		}
 
